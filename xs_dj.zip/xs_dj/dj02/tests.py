# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.
from django.core.mail import  send_mail

#def send_email(subject,message,send,receive):
# send_mail(subject,message,send,receive)

    # return "ok"

import  logging
logger = logging.getLogger(__name__)
print logger
logger.error('Something went wrong!')

